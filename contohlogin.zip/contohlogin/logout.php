
<?php
session_start();
unset ($_SESSION['namauser']);
echo "<center><h2>LOGOUT</h2>";
echo "<h4><p> anda telah logout</p></h4></center>";

?>

